---
name: Bug report
about: Report a reproducible problem using synthetic data
---

**App Hub version and host OS:**

**What happened, and what did you expect?**

**Steps to reproduce:**

**Sanitized log or screenshot (optional):**

Remove passwords, tokens, private IPs/hostnames, environment values, and personal
application data. For vulnerabilities, follow SECURITY.md instead of disclosing
sensitive details here.
