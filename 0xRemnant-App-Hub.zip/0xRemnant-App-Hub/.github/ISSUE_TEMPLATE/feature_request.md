---
name: Feature request
about: Suggest an improvement
---

**What are you trying to do?**

**Suggested behavior:**

**Any relevant examples using public or synthetic data?**
